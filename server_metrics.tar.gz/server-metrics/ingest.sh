#!/bin/bash

## To create with security disabled remove -u username:password to curl commands

HOST='localhost'
PORT=9200
VER=7.8.0
INDEX_NAME='server-metrics'
URL="http://${HOST}:${PORT}"
USERNAME=elastic
PASSWORD=changeme
printf "\n== Script for creating index and uploading data == \n \n"
printf "\n== Deleting old index \"${INDEX_NAME}\"  == \n\n"
curl -s -u ${USERNAME}:${PASSWORD} -X DELETE ${URL}/${INDEX_NAME}

printf "\n== Creating Index - ${INDEX_NAME} == \n\n"
curl -s  -u ${USERNAME}:${PASSWORD} -X PUT -H 'Content-Type: application/json' ${URL}/${INDEX_NAME} -d '{
   "settings":{
      "number_of_shards":1,
      "number_of_replicas":0
   },
   "mappings":{
      "properties":{
         "@timestamp":{
            "type":"date"
         },
         "accept":{
            "type":"long"
         },
         "deny":{
            "type":"long"
         },
         "host":{
            "type":"keyword"
         },
         "response":{
            "type":"float"
         },
         "service":{
            "type":"keyword"
         },
         "total":{
            "type":"long"
         }
      }
   }
}'

printf "\n== Bulk uploading data to index... \n"
printf "Elasticsearch: ${URL}， index: ${INDEX_NAME}\n"

curl -s -u ${USERNAME}:${PASSWORD} -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_1.json" > server-metrics_1.out 2>&1
printf "\nServer-metrics_1 uploaded"
curl -s -u ${USERNAME}:${PASSWORD} -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_2.json" > server-metrics_2.out 2>&1
printf "\nServer-metrics_2 uploaded"
curl -s -u ${USERNAME}:${PASSWORD} -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_3.json" > server-metrics_3.out 2>&1
printf "\nServer-metrics_3 uploaded"
curl -s -u ${USERNAME}:${PASSWORD} -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_4.json" > server-metrics_4.out 2>&1
printf "\nServer-metrics_4 uploaded\n\n"

curl -s -u ${USERNAME}:${PASSWORD} -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_5.json" > server-metrics_1.out 2>&1
printf "\nServer-metrics_5 uploaded"
curl -s -u ${USERNAME}:${PASSWORD} -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_6.json" > server-metrics_2.out 2>&1
printf "\nServer-metrics_6 uploaded"
curl -s -u ${USERNAME}:${PASSWORD} -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_7.json" > server-metrics_3.out 2>&1
printf "\nServer-metrics_7 uploaded"
curl -s -u ${USERNAME}:${PASSWORD} -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_8.json" > server-metrics_4.out 2>&1
printf "\nServer-metrics_8 uploaded\n\n"

curl -s -u ${USERNAME}:${PASSWORD} -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_9.json" > server-metrics_1.out 2>&1
printf "\nServer-metrics_9 uploaded"
curl -s -u ${USERNAME}:${PASSWORD} -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_10.json" > server-metrics_2.out 2>&1
printf "\nServer-metrics_10 uploaded"
curl -s -u ${USERNAME}:${PASSWORD} -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_11.json" > server-metrics_3.out 2>&1
printf "\nServer-metrics_11 uploaded"
curl -s -u ${USERNAME}:${PASSWORD} -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_12.json" > server-metrics_4.out 2>&1
printf "\nServer-metrics_12 uploaded\n\n"

curl -s -u ${USERNAME}:${PASSWORD} -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_13.json" > server-metrics_1.out 2>&1
printf "\nServer-metrics_13 uploaded"
curl -s -u ${USERNAME}:${PASSWORD} -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_14.json" > server-metrics_2.out 2>&1
printf "\nServer-metrics_14 uploaded"
curl -s -u ${USERNAME}:${PASSWORD} -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_15.json" > server-metrics_3.out 2>&1
printf "\nServer-metrics_15 uploaded"
curl -s -u ${USERNAME}:${PASSWORD} -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_16.json" > server-metrics_4.out 2>&1
printf "\nServer-metrics_16 uploaded\n\n"

curl -s -u ${USERNAME}:${PASSWORD} -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_17.json" > server-metrics_1.out 2>&1
printf "\nServer-metrics_17 uploaded"
curl -s -u ${USERNAME}:${PASSWORD} -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_18.json" > server-metrics_2.out 2>&1
printf "\nServer-metrics_18 uploaded"
curl -s -u ${USERNAME}:${PASSWORD} -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_19.json" > server-metrics_3.out 2>&1
printf "\nServer-metrics_19 uploaded"
curl -s -u ${USERNAME}:${PASSWORD} -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_20.json" > server-metrics_4.out 2>&1
printf "\nServer-metrics_20 uploaded\n\n"


printf "\n== Finished uploading data! \n"
